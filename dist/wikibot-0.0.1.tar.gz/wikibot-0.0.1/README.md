# WIKIBOT

This is a simple project for 
[GitHub-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
local tool ussage with LLM´s

TODO:
- Gradio interface
- Integrate image description
- much more...